<?php 
require('db.inc.php');

  $date = date("Y-m-d");
    
    if(isset($_POST['hospital_name']) && isset($_POST['general_beds']) && isset($_POST['icu_beds']) && isset($_POST['location']) && isset($_POST['full_address']) && isset($_POST['phone_number'])){
        if(mb_strlen(trim($_POST['hospital_name'])) > 0 && mb_strlen(trim($_POST['general_beds'])) > 0 && mb_strlen(trim($_POST['icu_beds'])) > 0 && mb_strlen(trim($_POST['location'])) > 0 && mb_strlen(trim($_POST['full_address'])) > 0 && mb_strlen(trim($_POST['phone_number'])) > 0){
            $query = mysqli_query($dbc, "INSERT INTO tbl_hospital_info (hospital_name, general_bed, icu_bed, hospital_location, hospital_full_address, hospital_phone_number) VALUES('".mysql_safe(trim($_POST['hospital_name']))."','".mysql_safe(trim($_POST['general_beds']))."','".mysql_safe(trim($_POST['icu_beds']))."','".mysql_safe(trim($_POST['location']))."','".mysql_safe(trim($_POST['full_address']))."','".mysql_safe(trim($_POST['phone_number']))."')");
            
            if(mysqli_affected_rows($dbc) > 0)
                echo json_encode(array('response' => 'success'));
            else
                echo json_encode(array('response' => 'error', 'result' => 'Could not save your tweet'));
                
        } else {
            echo json_encode(array('response' => 'error', 'result' => 'Please fill up all the empty fields before tweeting'));
        }
    } else {
        echo json_encode(array('response' => 'error', 'result' => 'Invalid Activity'));
    }
