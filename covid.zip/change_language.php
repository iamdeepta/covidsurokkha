<?php if(@$_GET['lang']=='en'){?>
<script type="text/javascript">

	/*$("#bengali_btn").css("display","block");
	$("#english_btn").css("display","none");*/

//cookies for language
function setCookie(key, value, expiry) {
  var expires = new Date();
  expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
  document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}

/*function translateEn(){
setCookie('googtrans', '/en/en',1);
}*/

function googleTranslateElementInit() {
	setCookie('googtrans', '/en/en',1);
  var x = new google.translate.TranslateElement({pageLanguage: 'en',layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: true}, 'google_translate_element');


}


</script>

<?php }elseif(@$_GET['lang']=='bn'){?>
	<script type="text/javascript">

		/*$("#bengali_btn").css("display","none");
		$("#english_btn").css("display","block");*/

//cookies for language
function setCookie(key, value, expiry) {
  var expires = new Date();
  expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
  document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}

/*function translateEn(){
setCookie('googtrans', '/en/en',1);
}*/

function googleTranslateElementInit() {
	setCookie('googtrans', '/en/bn',1);
  var x = new google.translate.TranslateElement({pageLanguage: 'en',layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: true}, 'google_translate_element');


}


</script>

<?php }else{?>

	<script type="text/javascript">

		/*$("#bengali_btn").css("display","none");
		$("#english_btn").css("display","block");*/

//cookies for language
function setCookie(key, value, expiry) {
  var expires = new Date();
  expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
  document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}

/*function translateEn(){
setCookie('googtrans', '/en/en',1);
}*/

function googleTranslateElementInit() {
	setCookie('googtrans', '/en/bn',1);
  var x = new google.translate.TranslateElement({pageLanguage: 'en',layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: true}, 'google_translate_element');


}


</script>

<?php }?>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>