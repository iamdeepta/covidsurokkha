<style type="text/css">
	svg path {
		/*fill: #01cfbe;*/   /*#00394f*/
		stroke: #eee;
		stroke-width:4.25;
	}

	svg path:hover{
		fill:#66E2D8;    /*#006284*/
		transition: 0.6s;
		cursor: pointer;
	}

	.data_table_area .dataTables_wrapper .table tbody tr td:nth-child(5){

		background-color: white;
		font: 500 14px quicksand,sans-serif;
	}
	.data_table_area .dataTables_wrapper .table tbody tr td:nth-child(7){

		background-color: white;
		font: 500 14px quicksand,sans-serif;
	}
	.data_table_area .dataTables_wrapper .table tbody tr td:nth-child(3){

		font: 500 14px quicksand,sans-serif;
	}
</style>

<link href="admin/css/addons/datatables.min.css" rel="stylesheet">