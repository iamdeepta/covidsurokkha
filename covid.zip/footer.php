<footer class="footer_area" id="footer_section" style="margin-top: 0px;">
<div class="footer_widgets_area pad_top" style="background-color: #e8e8f0 !important;">
<div class="container">
<div class="row">

	<div class="col-lg-5 col-md-6 col-sm-6" id="footer_part1">
<aside class="f_widget about_widget">
<div class="f_title">
	<?php if(@$_GET['lang']=='en'){?>
<h3>CovidSheba</h3>
<?php }elseif(@$_GET['lang']=='bn'){?>
	<h3 class="notranslate"><?=BanglaConverter::en2bn('CovidSheba');?></h3>
<?php }else{?>
	<h3 class="notranslate"><?=BanglaConverter::en2bn('CovidSheba');?></h3>
<?php }?>
</div>
<p>
	<?php if(@$_GET['lang']=='en'){?>
© <?php echo date(
	'Y');?> CovidSheba. All Rights Reserved.
<?php }elseif(@$_GET['lang']=='bn'){?>
	<span class="notranslate">© <?php echo BanglaConverter::en2bn(date(
	'Y'));?> <?=BanglaConverter::en2bn('CovidSheba');?></span>. All Rights Reserved.
<?php }else{?>
	<span class="notranslate">© <?php echo BanglaConverter::en2bn(date(
	'Y'));?> <?=BanglaConverter::en2bn('CovidSheba');?></span>. All Rights Reserved.
<?php }?>

<!-- এই রোগটি প্রথম চিনে হুবাইয়ের রাজধানী উহানে 2019 সালে সনাক্ত করা হয়েছিল এবং এর পর থেকে বিশ্বব্যাপী ছড়িয়ে পড়ে, ফলে 2019-2020 এর করোনভাইরাস মহামারী দেখা দেয়। -->
</p>
<!-- <ul class="nav">
<li>
<a href="#"><i class="fab fa-facebook"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-twitter"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-instagram"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-youtube"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-vimeo-v"></i></a>
</li>
</ul> -->
</aside>
</div>


<div class="col-lg-4 col-md-6 col-sm-6">
<aside class="f_widget contact_widget">
<div class="f_title">
<h3>Contacts</h3>
</div>
<div class="ct_wd_text">
<div class="media">
<div class="d-flex">
<i class="linearicons-telephone"></i>
</div>
<div class="media-body">
<h5>emergency call</h5>
<a href="tel:+8801773182803">
	<?php if(@$_GET['lang']=='en'){?>
<h4>+880175645</h4>
<?php }elseif(@$_GET['lang']=='bn'){?>
	<h4><?=BanglaConverter::en2bn('+880175645');?></h4>
<?php }else{?>
	<h4><?=BanglaConverter::en2bn('+880175645');?></h4>
<?php }?>
</a>
</div>
</div>
<!-- <div class="media">
<div class="d-flex">
<i class="linearicons-map-marker"></i>
</div>
<div class="media-body">
<p>
78-66 State Route 33, <br>
Brighton VIC 3186, AUSTRALIA
</p>
</div>
</div> -->
<!-- <div class="media">
<div class="d-flex">
<i class="fab fa-skype"></i>
</div>
<div class="media-body">
<a href="skype:md.rocky79">
<h6>Skype ID: <span>epidemic.org</span></h6>
</a>
</div>
</div> -->
<div class="media">
<div class="d-flex">
<i class="linearicons-envelope-open"></i>
</div>
<div class="media-body">
<a href="http://paul-themes.com/cdn-cgi/l/email-protection#295b464a42504b4d1810101c694e44484045074a4644">
<h6>Email: <span><span class="__cf_email__" data-cfemail="f69e9fb693869f92939b9f95d8998491">[email&#160;protected]</span></span></h6>
</a>
</div>
</div>
</div>
</aside>
</div>
<!-- <div class="col-lg-3 col-md-6 col-sm-6 col-6">
<aside class="f_widget list_widget">
<div class="f_title">
<h3>Prevention</h3>
</div>
<ul class="nav flex-column">
<li>
<a href="#"><i class="linearicons-radio-button"></i>Typical
Symptoms</a>
</li>
<li>
<a href="#"><i class="linearicons-radio-button"></i>How to
Protect</a>
</li>
<li>
<a href="#"><i class="linearicons-radio-button"></i>How are
spreading</a>
</li> -->
<!-- <li>
<a href="#"><i class="linearicons-radio-button"></i>Meet our
Doctors</a>
</li> -->
<!-- <li>
<a href="#"><i class="linearicons-radio-button"></i>About
Coronavirus</a>
</li>
</ul>
</aside>
</div> -->
<!-- <div class="col-lg-3 col-md-6 col-sm-6 col-6">
<aside class="f_widget list_widget">
<div class="f_title">
<h3>Protection</h3>
</div>
<ul class="nav flex-column">
<li>
<a href="#"><i class="linearicons-radio-button"></i>Typical
Symptoms</a>
</li>
<li>
<a href="#"><i class="linearicons-radio-button"></i>How to
Protect</a>
</li>
<li>
<a href="#"><i class="linearicons-radio-button"></i>How are
spreading</a>
</li> -->
<!-- <li>
<a href="#"><i class="linearicons-radio-button"></i>Meet our
Doctors</a>
</li> -->
<!-- <li>
<a href="#"><i class="linearicons-radio-button"></i>About
Coronavirus</a>
</li>
</ul>
</aside>
</div> -->


<div class="col-lg-3 col-md-6 col-sm-6" id="footer_part3">
<aside class="f_widget about_widget">
<div class="f_title">
<h3>About</h3>
</div>
<p>
	<?php if(@$_GET['lang']=='en'){?>
CovidSheba is an online service provided by
Afia Jalal Foundation Clinic.
<?php }elseif(@$_GET['lang']=='bn'){?>
	<span class="notranslate"><?=BanglaConverter::en2bn('CovidSheba');?></span> is an online service provided by
Afia Jalal Foundation Clinic.
<?php }else{?>
	<span class="notranslate"><?=BanglaConverter::en2bn('CovidSheba');?></span> is an online service provided by
Afia Jalal Foundation Clinic.
<?php }?>

<!-- এই রোগটি প্রথম চিনে হুবাইয়ের রাজধানী উহানে 2019 সালে সনাক্ত করা হয়েছিল এবং এর পর থেকে বিশ্বব্যাপী ছড়িয়ে পড়ে, ফলে 2019-2020 এর করোনভাইরাস মহামারী দেখা দেয়। -->
</p>
<!-- <ul class="nav">
<li>
<a href="#"><i class="fab fa-facebook"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-twitter"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-instagram"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-youtube"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-vimeo-v"></i></a>
</li>
</ul> -->
</aside>
</div>
</div>
</div>
</div>
<!-- <div class="footer_copyright">
<div class="container"> -->
<!-- <img src="assets/images/f-logo.png" alt=""> -->
<!-- <p>© Copyright
<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
              document.write(new Date().getFullYear());
            </script> Epidemic Organisation Ltd.</p> -->
<!-- <ul class="nav">
<li><a href="#">Term of Use</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Impressum</a></li>
</ul>
<h6>
Designed with <i class="linearicons-heart"></i> -->
 <!-- <span>creakits</span> -->
<!-- </h6>
</div>
</div> -->
</footer>