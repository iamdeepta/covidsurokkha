<div class="mobile_canvus_menu">
<div class="close_btn">
<img src="assets/images/icon/close-dark.png" alt="">
</div>
<div class="menu_part_lux">
<ul class="menu_list wd_scroll">
<li>
	<?php if(@$_GET['lang']=='en'){?>
	<a href="index.php">Home</a>
<?php }elseif(@$_GET['lang']=='bn'){?>
	<a href="index.php"><?=BanglaConverter::en2bn('Home');?></a>
<?php }else{?>
	<a href="index.php"><?=BanglaConverter::en2bn('Home');?></a>
<?php }?>
</li>
<!-- <li>
<a href="index.php">Prevention
<i class="linearicons-chevron-down"></i>
</a>
<ul class="list">
<li><a href="symptom.php">Typical Symptoms</a></li>
<li><a href="symptom-checker.php">Symptom Checker</a></li>
<li><a href="prevention.php">Prevention</a></li>
<li><a href="virus-checker.php">Coronavirus Checker</a></li>
<li><a href="tracker.php">Tracker</a></li>
<li><a href="maintenance.php">Maintenance</a></li>
<li><a href="faq.php">Faqs</a></li>
</ul>
</li> -->
<!-- <li><a href="appointment.php">Appphpointment</a></li>
<li>
<a href="#">Pages
<i class="linearicons-chevron-down"></i>
</a>
<ul class="list">
<li><a href="about.php">About</a></li>
<li><a href="doctors.php">Doctors</a></li>
<li><a href="sample-right-sidebar.php">Simple Sidebar</a></li>
<li><a href="typography.php">Typhography</a></li>
<li><a href="search.php">Search</a></li>
<li><a href="search-nothing.php">Not Found</a></li>
<li><a href="comingsoon.php">Coming Soon</a></li>
<li><a href="404.php">Error</a></li>
</ul>
</li> -->
<!-- <li>
<a href="index.php">Blog
<i class="linearicons-chevron-down"></i>
</a>
<ul class="list">
<li><a href="blog.php">Blog</a></li>
<li><a href="single-blog.php">Blog Details</a></li>
</ul>
</li> -->
<!-- <li><a href="#footer_section">Contact</a></li> -->
</ul>
</div>
<div class="menu_btm" onclick="menu_is_closed()">
	<?php //if(@$_GET['lang']=='en'){?>
		<!-- <a class="green_btn" id="bengali_btn" href="?lang=bn"><span style="margin-left: -10px;">BENGALI</span></a> -->
	<?php //}elseif(@$_GET['lang']=='bn'){?>
<!-- <a class="green_btn" id="english_btn" href="?lang=en"><span style="margin-left: -10px;">ENGLISH</span></a> -->
<?php //}else{?>
	<!-- <a class="green_btn" id="english_btn" href="?lang=en"><span style="margin-left: -10px;">ENGLISH</span></a> -->
<?php //}?>
<a class="green_btn" href="#footer_section"><span style="margin-left: -10px;">Contact</span></a>
</div>
</div>


<script type="text/javascript">
	$(document).ready(function(){

		menu_is_closed();
	});
	function menu_is_closed(){

		$('body').addClass('menu-is-closed');
		$('body').removeClass('menu-is-opened');
		
	}
</script>