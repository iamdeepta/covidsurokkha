<section class="sidebar_widget scroll_body">
<div class="info_sidebar_inner">
<div class="close_btn">
<img src="assets/images/icon/close.png" alt="">
</div>
<ul class="nav info_social">
<li>
<a href="#"><i class="fab fa-facebook"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-twitter"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-instagram"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-youtube"></i></a>
</li>
<li>
<a href="#"><i class="fab fa-vimeo-v"></i></a>
</li>
</ul>
<div class="info_title">
<h2>Get in touch</h2>
<p>If you have any question before we start, please fill below the contact form.</p>
</div>
<form action="#" class="appoinment_form js-form">
<div class="row">
<div class="col-lg-12">
<div class="form-group">
<input class="form-control" type="text" id="name" name="name" placeholder="" required />
<label><i class="linearicons-user"></i>Your Name</label>
</div>
</div>
<div class="col-lg-12">
<div class="form-group">
<input class="form-control" type="text" id="email" name="email" placeholder="" required />
<label><i class="linearicons-envelope-open"></i>Your Email
Address</label>
</div>
</div>
<div class="col-lg-12">
<div class="form-group">
<input class="form-control" type="text" id="number" name="number" placeholder="" required />
<label><i class="linearicons-telephone"></i>Your Phone
Number</label>
</div>
</div>
<div class="col-lg-12">
<div class="form-group">
<textarea name="message" id="message" cols="30" rows="10" class="form-control" required></textarea>
<label><i class="linearicons-document"></i>Your Message</label>
</div>
</div>
<div class="col-lg-12">
<div class="form-group checkbox_field">
<div class="checkbox">
<input type="checkbox" value="None" id="squared2" name="check" />
<label class="l_text" for="squared2">I accept the <span>Privacy Policy</span></label>
</div>
<button type="submit" class="green_btn" name="appoinment" id="appoinment" value="appoinment" data-value="appoinment">
Submit
</button>
</div>
</div>
</div>
<div class="success-message">
<i class="fa fa-check text-primary"></i> Thank you!. Your message
is successfully sent...
</div>
<div class="error-message">We're sorry, but something went wrong</div>
</form>
<div class="info_footer">
<p>© Copyright
<script>
              document.write(new Date().getFullYear());
            </script> Epidemic Organisation Ltd.
</p>
<h6>
Designed with <i class="linearicons-heart"></i>
by <span>creakits</span>
</h6>
</div>
</div>
</section>