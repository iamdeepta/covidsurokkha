<?php 

require('admin/db.inc.php');
    

    $doctor_query = mysqli_query($dbc, "SELECT * from tbl_doctors where doctor_remove_status=0 order by doctor_id asc");

    include 'english_to_bangla.php';

?>
<!DOCTYPE html>
<html lang="en" style="scroll-behavior: smooth;">

<!-- Mirrored from paul-themes.com/html/covid-19/symptom-checker.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 May 2021 12:12:20 GMT -->
<head>

<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link rel="icon" href="assets/images/favicon.png" type="image/png" />
<title class="notranslate">CovidSheba</title>

<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/vendors/fontawesome/css/all.min.css" />
<link rel="stylesheet" href="assets/vendors/linearicons/css/linearicons.css" />
<link rel="stylesheet" href="assets/vendors/mCustomScrollbar/jquery.mCustomScrollbar.min.css" />
<link rel="stylesheet" href="assets/vendors/animate-css/animate.css" />

<link href="assets/vendors/taging-js/tagsinput.css" rel="stylesheet" />
<link href="assets/vendors/nice-selector/css/nice-select.css" rel="stylesheet" />

<link rel="stylesheet" href="assets/css/style.css" />
<link rel="stylesheet" href="assets/css/responsive.css" />

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />

<style type="text/css">

	body{

		top: 0px !important;
	}

	.doctors_item{

		height: 470px;
	}

	#shiva
{
  width: 100px;
	height: 100px;
	background: red;
	-moz-border-radius: 50px;
	-webkit-border-radius: 50px;
	border-radius: 50px;
  float:left;
  margin:5px;
}

	canvas{

		display: none !important;
	}

	.goog-te-banner-frame{

		visibility: hidden !important;
		display: none !important;
	}

	.skiptranslate{

		display: none !important;
	}

	.form-control{
	border-bottom-color: #fff !important;
    color: #fff !important;
    padding: 10px !important;

    border-radius: 0 !important;
    box-shadow: none !important;
    font-weight: 500 !important;
    font-size: 16px !important;
    border: 0 !important; 
    border-bottom: 2px solid #fff !important;
    position: relative !important;
    z-index: 1 !important;
    width: 100% !important;
    background: 0 0 !important;

}
::placeholder{

	color: #c0bdd3 !important;
	opacity: 1 !important;
}

.checker_form .button{

	margin-top: 0px !important;
	margin-left: 15px !important;
}

.row{

	margin-top: 29px !important;
}

input[type=checkbox] + label {
  display: block;
  margin: 0em;
  cursor: pointer;
  padding: 0em;
}

input[type=checkbox] {
  display: none;
}

input[type=checkbox] + label:before {
  content: "\2713";
  border: 0.1em solid #fff;
  border-radius: 0.2em;
  display: inline-block;
  width: 1.7em;
  height: 1.7em;
  padding-left: 0.2em;
  padding-bottom: 0.3em;
  margin-right: 0.2em;
  vertical-align: middle;
  color: transparent;
  transition: .2s;
}

input[type=checkbox] + label:active:before {
  transform: scale(0);
}

input[type=checkbox]:checked + label:before {
  background-color: #01cfbe;
  border-color: #01cfbe;
  color: #fff;
}

input[type=checkbox]:disabled + label:before {
  transform: scale(1);
  border-color: #fff;
}

input[type=checkbox]:checked:disabled + label:before {
  transform: scale(1);
  background-color: #bfb;
  border-color: #bfb;
}


.doctors_item .doctors_img{

		padding-top: 0px !important;
	}

	.doctors_item .doctors_text{

		padding: 10px 15px !important;
	}


	@media screen and (max-width: 460px) {
  

		#header_menu_bar1{

			display: block !important;
		}

		#mbl_lang{

			display: block !important;
		}

		#search_header{

			display: none !important;
		}

		#call_doctor_now_section{

			padding-top: 1px !important;
			padding-bottom: 20px !important;
			display: none !important;

		}

		#call_doctor_now_section1{

			padding-top: 1px !important;
			padding-bottom: 14px !important;
			display: block !important;

		}

		#call_doctor_now_section1 .right{

			margin-top: 0px !important;
		}

		.doctors_item .doctors_img{

			min-height: 150px !important;

		}

		.doctors_item{

			max-width: 220px !important;
		}

		#doc_img{

			height: 150px !important;
		}

		#basic_details{

			margin-top: 20px !important;
		}


		#fill_the_simple_form_text{

			margin-top: -70px !important;
		}

		#fill_the_simple_form_below_text{

			font-size: 22px !important;
		}

		#footer_part1{

			margin-bottom: 0px !important;
		}

		#footer_part3{

			margin-bottom: 0px !important;
		}

		#main_symptoms_div{

			margin-bottom: 0px !important;
		}

		#other_symptoms_div{

			margin-bottom: 0px !important;
		}

		.doctors_item{

		height: auto !important;
	}
		/*#symptom_card1{

			height: 250px !important;
		}

		#symptom_card2{

			height: 185px !important;
		}

		#symptom_card3{

			height: 250px !important;
		}

		#symptom_card4{

			height: 250px !important;
		}*/
}


</style>
</head>
<body data-scroll-animation="true">
<div class="body_wrapper">

<div class="preloader">
<div class="three-bounce">
<div class="one"></div>
<div class="two"></div>
<div class="three"></div>
</div>
</div>


<?php include 'mobile_canvas_menu.php';?>


<div class="body_capture"></div>
<?php include 'sidebar.php';?>


<?php include 'header_white.php';?>


<section class="breadcrumb_area dark_breadcrumb" id="top_section">
<!-- <img class="tp_img" src="assets/images/breadcrumb/checker-banner-map.png" alt=""> -->
<div class="container">
<div class="breadcrumb_text">
<h6>You are not feeling well?</h6>
<h3>Coronavirus Symptom Checker</h3>

<div class="nav justify-content-center" style="text-align: center;"><div style="width: 50%;height: 5px;background-color: lightgray;border-radius: 6px"><div id="progress_bar" style="width: 20%;background-color: #01cfbe;color: #01cfbe;height: 5px;border-radius: 6px"></div></div></div>
<!-- <ul class="nav justify-content-center">
<li><a href="index.html">Home</a></li>
<li><a href="prevention.html">Prevention</a></li>
<li><a href="checker.html">Symptom Checker</a></li>
</ul> -->
</div>
<div class="row checker_box_inner">
<div class="col-lg-6">
<div class="checker_simple_text" id="fill_the_simple_form_text">
<h3 id="fill_the_simple_form_below_text">Fill the simple form below</h3>
<p>Enter more symptoms for more accurate results, starting with your most severe symptom.
Look through a list of common symptoms.
</p>
<!-- <div class="row">
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-lifebuoy"></i>
</div>
<div class="media-body">
<h4>We help you</h4>
<p>Our experts gives you advice</p>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-finger-tap"></i>
</div>
<div class="media-body">
<h4>Easy to use</h4>
<p>4 steps, it’s quite simple</p>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-tags"></i>
</div>
<div class="media-body">
<h4>100% FREE</h4>
<p>Don’t worry about the cost</p>
</div>
</div>
</div>
<div class="col-sm-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-bubble-question"></i>
</div>
<div class="media-body">
<h4>Got questions?</h4>
<p>Contact us, we answer you</p>
</div>
</div>
</div>
</div> -->
</div>
</div>
<div class="col-lg-6">
<div class="checker_form" id="basic_details">
<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->
<h4 style="color: white">Basic Details</h4>
<p id="error_msg" style="color: #f37878"></p>
<div class="row">
<div class="col-lg-6">
	<div class="form-group">
	<input type="text" class="form-control" id="full_name" name="full_name" placeholder="Full Name">
</div>

<!-- <div class="radio_btn">
<h5>What’s your gender?</h5>
<div class="select_conversation">
<input type="radio" name="male" id="male" value="male">
<label for="male">Male</label>
</div>
<div class="select_conversation">
<input type="radio" name="male" id="female" value="female">
<label for="female">Female</label>
</div>
</div> -->
<!-- <select class="nice_select checker_select">
<option value="1">Select your Region</option>
<option value="2">Islam</option>
<option value="3">Islam</option>
</select> -->
</div>
<div class="col-lg-6">
	<div class="form-group">
	<input type="text" class="form-control" id="mobile_number" name="mobile_number" placeholder="Mobile Number">
	</div>
<!-- <select class="nice_select checker_select">
<option value="1">What’s your age?</option>
<option value="2">25</option>
<option value="3">26</option>
</select> -->

</div>
<div class="button">
<a class="submit_btn" href="javascript:void(0)" id="next1" onclick="submit_basic_details();">Next</a>
</div>
</div>
</div>

<div class="checker_form" id="symptoms1" style="display: none;">
<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->
<h4 style="color: white">Are you facing any of the below symptoms?</h4>
<p id="error_msg1" style="color: #f37878"></p>
<div class="row">
<div class="col-lg-6">
	<div class="form-group" id="main_symptoms_div">
	<input class="main_symptoms" type="checkbox" id="dry_cough" name="dry_cough" value="Dry cough">
  <label for="dry_cough" style="color: #fff"> Dry cough</label><br>
  <input class="main_symptoms" type="checkbox" id="fever" name="fever" value="Fever">
  <label for="fever" style="color: #fff"> Fever</label><br>
  <input class="main_symptoms" type="checkbox" id="loss_of_taste_or_smell" name="loss_of_taste_or_smell" value="Loss of taste or smell">
  <label for="loss_of_taste_or_smell" style="color: #fff"> Loss of taste or smell</label><br>
</div>


</div>
<div class="col-lg-6">
	<div class="form-group">
	<input class="main_symptoms" type="checkbox" id="difficulty_in_breathing" name="difficulty_in_breathing" value="Difficulty in breathing">
  <label for="difficulty_in_breathing" style="color: #fff"> Difficulty in breathing</label><br>
  <input class="main_symptoms" type="checkbox" id="tiredness" name="tiredness" value="Tiredness">
  <label for="tiredness" style="color: #fff"> Tiredness</label><br>
  <input class="main_symptoms" type="checkbox" id="none_of_the_above1" name="none_of_the_above1" value="None" onclick="none_of_the_above1_checked()">
  <label for="none_of_the_above1" style="color: #fff"> None of the above</label><br>

	</div>

</div>

<div class="button">
<a class="submit_btn" id="next2" href="javascript:void(0)" onclick="symptoms1();">Next</a>
</div>
</div>
</div>


<div class="checker_form" id="symptoms2" style="display: none;">
<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->
<h4 style="color: white">What about any of these symptoms?</h4>
<p id="error_msg2" style="color: #f37878"></p>
<div class="row">
<div class="col-lg-6">
	<div class="form-group" id="other_symptoms_div">
	<input class="other_symptoms" type="checkbox" id="body_aches" name="body_aches" value="Body aches">
  <label for="body_aches" style="color: #fff"> Body aches</label><br>
  <input class="other_symptoms" type="checkbox" id="nasal_congestion" name="nasal_congestion" value="Nasal congestion">
  <label for="nasal_congestion" style="color: #fff"> Nasal congestion</label><br>
  <input class="other_symptoms" type="checkbox" id="runny_nose" name="runny_nose" value="Runny nose">
  <label for="runny_nose" style="color: #fff"> Runny nose</label><br>
</div>


</div>
<div class="col-lg-6">
	<div class="form-group">
	<input class="other_symptoms" type="checkbox" id="sore_throat" name="sore_throat" value="Sore throat">
  <label for="sore_throat" style="color: #fff"> Sore throat</label><br>
  <input class="other_symptoms" type="checkbox" id="headache" name="headache" value="Headache">
  <label for="headache" style="color: #fff"> Headache</label><br>
  <input class="other_symptoms" type="checkbox" id="none_of_the_above2" name="none_of_the_above2" value="None" onclick="none_of_the_above2_checked()">
  <label for="none_of_the_above2" style="color: #fff"> None of the above</label><br>

	</div>

</div>

<div class="button">
<a class="submit_btn" id="next3" href="javascript:void(0)" onclick="symptoms2();">Next</a>
</div>
</div>
</div>


<div class="checker_form" id="radio1" style="display: none;">
<!-- <input type="text" data-role="tagsinput" value="fever,seneeze" placeholder="Start typing your symptoms..."> -->
<h4 style="color: white">Other Inquiry</h4>
<p id="error_msg3" style="color: #f37878"></p>
<div class="row">

<div class="col-lg-12">
	
	<div class="radio_btn">
<h5>I stay in a Containment zone/ Red Zone</h5>
<div class="select_conversation">
<input type="radio" name="red_zone" id="red_zone_yes" value="yes">
<label for="red_zone_yes">Yes</label>
</div>
<div class="select_conversation">
<input type="radio" name="red_zone" id="red_zone_no" value="no">
<label for="red_zone_no">No</label>
</div>
</div>


<div class="radio_btn">
<h5>Are you a healthcare provider- doctor, nurse, hospital staff?</h5>
<div class="select_conversation">
<input type="radio" name="healthcare" id="healthcare_yes" value="yes">
<label for="healthcare_yes">Yes</label>
</div>
<div class="select_conversation">
<input type="radio" name="healthcare" id="healthcare_no" value="no">
<label for="healthcare_no">No</label>
</div>
</div>


<div class="radio_btn">
<h5>Have you recently come in contact with someone tested positively for COVID-19?</h5>
<div class="select_conversation">
<input type="radio" name="positive" id="positive_yes" value="yes">
<label for="positive_yes">Yes</label>
</div>
<div class="select_conversation">
<input type="radio" name="positive" id="positive_no" value="no">
<label for="positive_no">No</label>
</div>
</div>


<div class="radio_btn">
<h5>Do you have any of these Pre-existing conditions- high BP, Heart problem, Diabetes, Asthma, Lung problems - COPD, Pneumonia or any respiratory disease?</h5>
<div class="select_conversation">
<input type="radio" name="condition" id="condition_yes" value="yes">
<label for="condition_yes">Yes</label>
</div>
<div class="select_conversation">
<input type="radio" name="condition" id="condition_no" value="no">
<label for="condition_no">No</label>
</div>
</div>

</div>

<div class="button">
<a class="submit_btn" id="confirm" href="javascript:void(0)" onclick="confirm();">Confirm</a>
</div>
</div>
</div>
</div>
</div>
</div>
</section>


<!-- <section class="home_about_corona">
<div class="container">
<div class="danger_box alert-danger">
<p><i class="linearicons-warning"></i> The symptom checker results show a list of possible
conditions, not an actual diagnosis. Consult
your doctor if you are concerned.</p>
</div>
<div class="row">
<div class="col-lg-6">
<div class="symptom_instruction_text">
<h4>Instruction</h4>
<p>If you’re feeling under the weather but aren’t sure what it could be, an online symptom
checker can help you identify whether you need to seek immediate medical attention.
</p>
<p>Online symptom checkers are calculators that ask users to input details about their signs
and symptoms of sickness, along with their gender, age and location. Using computerised
algorithms, the self diagnosis tool will then give a range of conditions that might fit
the problems a user is experiencing. They can also advice someone whether to seek advice
from a healthcare professional and the level of urgency in which to do so.
</p>
<a class="text_btn" href="#">Read more <i class="linearicons-arrow-right"></i></a>
</div>
</div>
<div class="col-lg-6">
<div class="home_ab_text how_to_use">
<div class="home_ab_text_inner">
<div class="home_ab_item ">
<h4>How to use it?</h4>
<p>Enter symptoms in your own words or pick from the drop-down list:</p>
<ul class="nav">
<li><a href="#"><i class="linearicons-arrow-right"></i>Medical terms are best
but if you don’t know them, just enter your
symptoms in normal, everyday language.
</a></li>
<li><a href="#"><i class="linearicons-arrow-right"></i>Enter each symptom
separately or put them all on one line but separated
by commas.</a></li>
<li><a href="#"><i class="linearicons-arrow-right"></i>Enter the meaning of
abnormal test results in words rather than numbers:
for example, ‘high blood pressure’ rather than ‘BP 160/100’</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</section> -->


<section class="result_area" id="result_area">
<div class="container">
<div class="row" style="margin-top: -20px !important;">
<div class="col-lg-4">
<div class="result_box" id="result_box">
	<div id="result_box_inside">
<h4>Results</h4>
<ul class="nav flex-column">
	<table class="table">
		<tbody>
			<tr>
				<td>Name:</td>
				<!-- <td></td> -->
				<td style="color: #01cfbe;font-weight: bold" id="user_name">N/A</td>
			</tr>

			<tr>
				<td>Main Symptoms:</td>
				<!-- <td></td> -->
				<td style="color: #01cfbe;font-weight: bold" id="m_symptoms">N/A</td>
			</tr>

			<tr>
				<td>Other Symptoms:</td>
				<!-- <td></td> -->
				<td style="color: #01cfbe;font-weight: bold" id="o_symptoms">N/A</td>
			</tr>
		</tbody>
	</table>
<!-- <li>
<span>Symptoms:</span>
<a class="tag" href="#">fever</a>
<a class="tag" href="#">sore throat</a>
<a class="tag" href="#">sore throat</a>
</li> -->
<!-- <li>
<span>Gender:</span>
<a href="#">Female</a>
</li>
<li>
<span>Age range:</span>
<a href="#">25-30 yrs</a>
</li>
<li>
<span>Region:</span>
<a href="#">Italy</a>
</li> -->
</ul>
<div class="circle_inner" style="border-radius: 50%;background-color: white;height: 150px;width: 150px;box-shadow: 0px 0px 2px 0px ;">
<div class="second circle" style="text-align: center;padding-top: 40%">
<!-- <span id="count" class="count" style="font-size: 40px;"></span><span>%</span> -->
<span id="count" class="count" style="font-size: 20px;font-weight: bold">N/A</span>

</div>
</div>
<!-- <div id="shiva"><span class="count">200</span></div> -->
<!-- <div class="bottom_text text-center">
<h6>Estimable state:</h6>
<h3 id="risk">N/A</h3>
</div> -->
</div>
</div>

</div>

<div class="col-lg-8">
<div class="result_inner_text">
<div class="result_item" id="result_item">
<h4 id="hi_name">Our Advice</h4>
<p id="hi_text">Please provide all the information asked above to have covid-19 result and advices. Thank you.</p>
</div>
<div class="result_item" id="our_advice" style="display: none">
<h4 id="our_advice_header"></h4>
<p id="our_advice_text11"><span style="color: #26b864;">✓ </span><span id="our_advice_text1"></span></p>
<p id="our_advice_text22"><span style="color: #26b864;">✓ </span><span id="our_advice_text2"></span></p>
<p id="our_advice_text33"><span style="color: #26b864;">✓ </span><span id="our_advice_text3"></span></p>
<p id="our_advice_text44"><span style="color: #26b864;">✓ </span><span id="our_advice_text4"></span></p>
<p id="our_advice_text55"><span style="color: #26b864;">✓ </span><span id="our_advice_text5"></span></p>
<p id="our_advice_text66"><span style="color: #26b864;">✓ </span><span id="our_advice_text6"></span></p>
<p id="our_advice_text77"><span style="color: #26b864;">✓ </span><span id="our_advice_text7"></span></p>
</div>
<div class="result_item">
<!-- <h4>Suggestion</h4>
<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit
laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure
reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel
illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p> -->
<a class="green_btn" id="check_btn" href="#top_section"><!-- <i class="linearicons-pulse"></i>  -->Check First</a>
</div>
</div>


</div>
</div>
</div>
</section>



<section class="data_table_area" id="doctors_header_section" style="margin-top: 70px;background-color: #f5f5f9;">
<div class="container">
<div class="main_title text-center">
<h5>Meet Our Expert Doctors</h5>
<h2>Our Doctors</h2>
</div>
<!-- <div class="doctors_bio row">
<div class="col-lg-6">
<div class="doctors_img text-right wow fadeInUp" data-wow-delay="400ms"><img src="assets/images/doctors/doctors-img.png" alt="">
</div>
</div>
<div class="col-lg-6">
<div class="doctors_bio_text text-left wow fadeInUp" data-wow-delay="400ms">
<h5>Founder and Owner</h5>
<h3>Dr Pamela Smith</h3>
<p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id
quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor
repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum
necessitatibus.</p>
<img src="assets/images/doctors/signature.png" alt="">
</div>
</div>
</div> -->
</div>
</section>


<section class="doctors_area" style="margin-top: -240px;background-color: #f5f5f9">
<div class="container">
<div class="row doctors_inner">

	<?php 
	$doctor_count=0;
	$delay = 0;
	while($doctor_query && $result_doctor=mysqli_fetch_array($doctor_query, MYSQLI_ASSOC)){
        $doctor_count++;
        $delay = $delay+100;
?>
<div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="<?=$delay?>ms">
<div class="doctors_item">
<div class="doctors_img">
<img id="doc_img" class="img-fluid" src="admin/files/<?=$result_doctor['doctor_image']?>" alt="doctor<?=$doctor_count?>" style="height:258px;width:auto;object-fit: contain;">
</div>
<div class="doctors_text">
<h6><?=$result_doctor['doctor_post']?></h6>
<h3 style="font-size: 20px"><?=$result_doctor['doctor_name']?></h3>
<p style="line-height: 20px"><?=$result_doctor['doctor_hospital']?>
</p>
<?php if(@$_GET['lang']=='en'){?>
<p style="line-height: 20px">Consultation Time: <?=$result_doctor['doctor_consultation_time']?></p>
<?php }elseif(@$_GET['lang']=='bn'){

	if($result_doctor['doctor_consultation_time']=='12:00 pm' || $result_doctor['doctor_consultation_time']=='12:30 pm' || $result_doctor['doctor_consultation_time']=='1:00 pm' || $result_doctor['doctor_consultation_time']=='1:30 pm' || $result_doctor['doctor_consultation_time']=='2:00 pm' || $result_doctor['doctor_consultation_time']=='2:30 pm' || $result_doctor['doctor_consultation_time']=='3:00 pm' || $result_doctor['doctor_consultation_time']=='3:30 pm' || $result_doctor['doctor_consultation_time']=='4:00 pm' || $result_doctor['doctor_consultation_time']=='4:30 pm' || $result_doctor['doctor_consultation_time']=='5:00 pm' || $result_doctor['doctor_consultation_time']=='5:30 pm' || $result_doctor['doctor_consultation_time']=='6:00 pm' || $result_doctor['doctor_consultation_time']=='6:30 pm' || $result_doctor['doctor_consultation_time']=='7:00 pm' || $result_doctor['doctor_consultation_time']=='7:30 pm'){
	?>
	<p style="line-height: 20px">Consultation Time: <span class="notranslate">বেলা <?=BanglaConverter::en2bntime($result_doctor['doctor_consultation_time']);?></span></p>
<?php }else{?>

	<p style="line-height: 20px">Consultation Time: <?=BanglaConverter::en2bn($result_doctor['doctor_consultation_time']);?></p>
	<?php
} }else{

		if($result_doctor['doctor_consultation_time']=='12:00 pm' || $result_doctor['doctor_consultation_time']=='12:30 pm' || $result_doctor['doctor_consultation_time']=='1:00 pm' || $result_doctor['doctor_consultation_time']=='1:30 pm' || $result_doctor['doctor_consultation_time']=='2:00 pm' || $result_doctor['doctor_consultation_time']=='2:30 pm' || $result_doctor['doctor_consultation_time']=='3:00 pm' || $result_doctor['doctor_consultation_time']=='3:30 pm' || $result_doctor['doctor_consultation_time']=='4:00 pm' || $result_doctor['doctor_consultation_time']=='4:30 pm' || $result_doctor['doctor_consultation_time']=='5:00 pm' || $result_doctor['doctor_consultation_time']=='5:30 pm' || $result_doctor['doctor_consultation_time']=='6:00 pm' || $result_doctor['doctor_consultation_time']=='6:30 pm' || $result_doctor['doctor_consultation_time']=='7:00 pm' || $result_doctor['doctor_consultation_time']=='7:30 pm'){
	?>
	<p style="line-height: 20px">Consultation Time: <span class="notranslate">বেলা <?=BanglaConverter::en2bntime($result_doctor['doctor_consultation_time']);?></span></p>

<?php }else{?>

	<p style="line-height: 20px">Consultation Time: <?=BanglaConverter::en2bn($result_doctor['doctor_consultation_time']);?></p>
<?php } }?>
<!-- <ul class="nav">
<li><a href="#"><i class="fab fa-facebook"></i></a></li>
<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
<li><a href="#"><i class="fab fa-instagram"></i></a></li>
</ul> -->
</div>
</div>
</div>


<section class="check_now_area" id="call_doctor_now_section1" style="margin-top: 0px;margin-bottom: 30px;display: none;">
<div class="container">
<div class="row m-0 justify-content-between" style="margin-top: 0px !important">
<div class="left">
<div class="media">
<div class="d-flex">
<img src="assets/images/check-1.png" alt="" />
<img src="assets/images/check-2.png" alt="" />
<img src="assets/images/check-3.png" alt="" />
</div>
<div id="check_now_text1" class="media-body">
<h4 id="contact_us_to_get_service" style="font-size: 24px">Contact us to get the service</h4>
<!-- <p >
Give a call to one of our renowned doctors.
</p> -->
</div>
</div>
</div>
<div class="right" id="check_now_button" >

	<a class=" wow fadeInRight" data-wow-delay="400ms" href="tel:+880177" style="font-size: 16px;background-color: white;padding: 10px 30px;color: #58547e;font-weight: bold;border-radius: 6px;">Call Now<i class="linearicons-phone" style="margin-left: 4px;font-weight: bold"></i></a>

 </div>
</div>
</div>
</section>

<?php }?>

</div>
</div>
</section>


<section class="check_now_area" id="call_doctor_now_section" style="margin-top: 20px;margin-bottom: 0px;">
<div class="container">
<div class="row m-0 justify-content-between">
<div class="left">
<div class="media">
<div class="d-flex">
<img src="assets/images/check-1.png" alt="" />
<img src="assets/images/check-2.png" alt="" />
<img src="assets/images/check-3.png" alt="" />
</div>
<div id="check_now_text" class="media-body">
<?php if(@$_GET['lang']=='en'){?>
<h4 >Contact us to get the service</h4>
<?php }elseif(@$_GET['lang']=='bn'){?>
	<h4 style="font-size: 32px">Contact us to get the service</h4>
<?php }else{?>
	<h4 style="font-size: 32px">Contact us to get the service</h4>
<?php }?>
<!-- <p >
Give a call to one of our renowned doctors.
</p> -->
</div>
</div>
</div>
<div class="right check_now_button" id="check_now_button">

	<a id="call_now" class="icon_btn wow fadeInRight" data-wow-delay="400ms" href="tel:+880177">Call Now<i class="linearicons-phone"></i></a>

 </div>
</div>
</div>
</section>

<!-- <section class="about_question_area">
<div class="container">
<div class="main_title text-center">
<h5>No more about symptoms</h5>
<h2>Questions & Answers</h2>
</div>
<div class="row about_ques_inner">
<div class="col-lg-4">
<div class="about_ques_item">
<h4>How do I know if I’m sick nad what to do?</h4>
<p>Using an online symptom checker is simple. For instance, you might be a 45 year old woman
from the UK who is currently experiencing headache, a fever and a sore throat. Inputting
this information into the symptom checker will give you some likely ‘common’ diagnoses.
These include: strep throat, tonsillitis, sinusitis and flu.
</p>
<a class="text_btn" href="#">Read more <i class="linearicons-arrow-right"></i></a>
</div>
</div>
<div class="col-lg-4">
<div class="about_ques_item">
<h4>What’s the difference between a sign and a symptom?</h4>
<p>‘Sign’ and ‘symptom’ are often used interchangeably, but if we’re going to be pedantic,
they do actually mean different things.
If you’re feeling ill it might not be immediately obvious to somebody looking at you
that you’re sick. For instance, if you’re experiencing pain, fatigue or dizziness, only
you know what that feels like. These are symptoms - which can only be described by the
person experiencing them.
</p>
<a class="text_btn" href="#">Read more <i class="linearicons-arrow-right"></i></a>
</div>
</div>
<div class="col-lg-4">
<div class="about_ques_item">
<h4>How safe and accurate are symptom checkers?</h4>
<p>Most doctors agree that online symptom checkers are can encourage people with
life-threatening symptoms to seek urgent attention, potentially saving lives. They’re
also useful for reassuring patients who may have sought urgent care when they didn’t
need to.
 </p>
<a class="text_btn" href="#">Read more <i class="linearicons-arrow-right"></i></a>
</div>
</div>
</div>
<div class="warning_box alert-warning">
<div class="media">
<div class="d-flex">
<i class="linearicons-notification"></i>
</div>
<div class="media-body">
<h4>Disclaimer</h4>
<p>This symptom checker is provided by Isabel Healthcare Limited. Isabel Symptom Checker
("Isabel") and any content accessed through Isabel is for informational purposes only,
and is not intended to constitute professional medical advice, diagnosis or treatment.
EMIS shall be in no way responsible for your use of Isabel, or any information that you
obtain from Isabel. You acknowledge that when using Isabel you do so at your own choice
and in agreement with this disclaimer. Do not ignore or delay obtaining professional
medical advice because of information accessed through Isabel. Seek immediate medical
assistance or call your doctor for all medical emergencies. By using Isabel you agree to
the <a href="#">terms and conditions.</a></p>
</div>
</div>
</div>
</div>
</section> -->


<!-- <section class="app_area">
<div class="container">
<div class="row">
<div class="col-lg-6">
<div class="app_text">
<h2>Get <span>epidemic</span> app!</h2>
<p>
Download our app now, track Coronavirus cases real-time and
follow instant updates.
</p>
<a class="wow fadeIn" data-wow-delay="400" href="#"><img src="assets/images/apple-btn.png" alt="" /></a>
<a class="wow fadeIn" data-wow-delay="500" href="#"><img src="assets/images/google-btn.png" alt="" /></a>
</div>
</div>
<div class="col-lg-6">
<div class="app_mobile">
<div class="mobile_image">
<img src="assets/images/mobile-1.png" alt="" />
<img class="wow fadeInUp" data-wow-delay="500ms" src="assets/images/mobile-2.png" alt="" />
</div>
<ul class="corona_img nav">
<li>
<img src="assets/images/icon/app-virus-1.png" alt="" />
</li>
<li>
<img src="assets/images/icon/app-virus-2.png" alt="" />
</li>
<li>
<img src="assets/images/icon/app-virus-3.png" alt="" />
</li>
<li data-parallax='{"y": -100}'>
<img src="assets/images/icon/app-virus-4.png" alt="" />
</li>
<li data-parallax='{"y": 100}'>
<img src="assets/images/icon/app-virus-5.png" alt="" />
</li>
 <li>
<img src="assets/images/icon/app-virus-6.png" alt="" />
</li>
<li data-parallax='{"y": -200}'>
<img src="assets/images/icon/app-virus-7.png" alt="" />
</li>
</ul>
</div>
</div>
</div>
</div>
</section> -->


<!-- <section class="subscribe_area">
<div class="container">
<div class="row">
<div class="col-lg-6">
<div class="media">
<div class="d-flex">
<i class="linearicons-mailbox-full"></i>
</div>
<div class="media-body">
<h4>Subscribe our newsletter</h4>
<p>
Join our subscribers list to get latest news and updates
about COVID-19 delivered directly in your inbox.
</p>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="mail_box">
<div class="input-group">
<input type="text" class="form-control" placeholder="&#xe997; Enter your email" aria-label="Recipient's username" aria-describedby="button-addon2" />
<div class="input-group-append">
<button class="btn btn-outline-secondary" type="button" id="button-addon2">
<i class="linearicons-arrow-right"></i>
</button>
</div>
</div>
<label class="container-checkbox">I accept the <span>Privacy Policy.</span>
<input type="checkbox" />
<span class="checkmark"></span>
</label>
</div>
</div>
</div>
</div>
</section> -->


<?php include 'footer.php';?>

</div>
<!-- <div class="modal fade search_modal" id="exampleModal" tabindex="-1" role="dialog" aria-hidden="true">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<img src="assets/images/icon/close-white.png" alt="">
</button>
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-body">
<div class="input-group">
<input type="text" class="form-control" placeholder="Type here..." aria-label="Recipient's username">
<div class="input-group-append">
<button class="btn btn-outline-secondary" type="button"><i class="linearicons-magnifier"></i></button>
</div>
</div>
</div>
</div>
</div>
</div> -->

<?php include 'change_language.php';?>



<script src="assets/js/jquery-3.4.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/vendors/corona-live/dashboard.js"></script>
<script src="assets/vendors/isotop/imagesloaded.pkgd.min.js"></script>
<script src="assets/vendors/isotop/isotope.pkgd.min.js"></script>
<script src="assets/vendors/slick/slick.min.js"></script>
<script src="assets/vendors/scroll-animation/jquery.parallax-scroll.js"></script>
<script src="assets/vendors/taging-js/tagsinput.js"></script>
<script src="assets/vendors/nice-selector/js/jquery.nice-select.min.js"></script>
<script src="assets/vendors/counterup/jquery.waypoints.min.js"></script>
<script src="assets/vendors/circle-progress/circle-progress.min.js"></script>
<script src="assets/vendors/mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="assets/vendors/animate-css/wow.min.js"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCEQhXdvO2Yz16kSBaeBzLt7wWRkECXmlg"></script>
<script src="assets/js/gmaps.min.js"></script>
<script src="assets/js/map-active.js"></script>
<script src="assets/js/circle-progress.js"></script>
<script src="assets/js/jquery.validate.min.js"></script>
<script src="assets/js/theme.js"></script>

<!-- menu active change -->
<script type="text/javascript">
  $(function(){
    $('.navbar-nav .nav-link').filter(function(){return this.href==location.href}).parent().addClass('active').siblings().removeClass('active')
    $('.navbar-nav .dropdown-item').filter(function(){return this.href==location.href}).parent().parent().addClass('active').siblings().removeClass('active')
    $('.navbar-nav .dropdown-item').filter(function(){return this.href==location.href}).addClass('active').siblings().removeClass('active')
    $('.navbar-nav a').click(function(){
      $(this).parent().addClass('active').siblings().removeClass('active')  
    })
    
  })
  </script>


<script type="text/javascript">

	var numbers = {
  0: '০',
  1: '১',
  2: '২',
  3: '৩',
  4: '৪',
  5: '৫',
  6: '৬',
  7: '৭',
  8: '৮',
  9: '৯'
};

function replaceNumbers(input) {
  var output = [];
  for (var i = 0; i < input.length; ++i) {
    if (numbers.hasOwnProperty(input[i])) {
      output.push(numbers[input[i]]);
    } else {
      output.push(input[i]);
    }
  }
  return output.join('');
}

function replaceString(str){

	dhaka_str = str.replace("Dhaka","ঢাকা");

	return dhaka_str;
}

/*document.getElementById('r').textContent = replaceNumbers('৯  ৭  ৩');*/

//getting url last string
 var url = window.location.href;
 var parts = url.split('=');
var lastSegment = parts.pop() || parts.pop();

		$(document).ready(function(){

		$(".check_now_button").mouseover(function(){

	if (lastSegment=='en') {


  		$("#call_now").html('+8801839832992');
  		

  	}else if(lastSegment=='bn'){

  		$("#call_now").html(replaceNumbers('+8801839832992'));
  		
  	}else{

  		$("#call_now").html(replaceNumbers('+8801839832992'));
  		
  	}
  	});

$(".check_now_button").mouseout(function(){

	if (lastSegment=='en') {


  		$("#call_now").html('Call Now<i class="linearicons-phone"></i>');
  		

  	}else if(lastSegment=='bn'){

  		$("#call_now").html('এখন ডাকো<i class="linearicons-phone"></i>');
  		
  	}else{

  		$("#call_now").html('এখন ডাকো<i class="linearicons-phone"></i>');
  		
  	}

  		
  	});


		});

function none_of_the_above1_checked(){

	var none_of_the_above1 = document.getElementById("none_of_the_above1");
	var dry_cough = document.getElementById("dry_cough");
	var difficulty_in_breathing = document.getElementById("difficulty_in_breathing");
	var fever = document.getElementById("fever");
	var tiredness = document.getElementById("tiredness");
	var loss_of_taste_or_smell = document.getElementById("loss_of_taste_or_smell");

		if(none_of_the_above1.checked==true){

				dry_cough.checked=false;
				dry_cough.disabled='disabled';
				difficulty_in_breathing.checked=false;
				difficulty_in_breathing.disabled='disabled';
				fever.checked=false;
				fever.disabled='disabled';
				tiredness.checked=false;
				tiredness.disabled='disabled';
				loss_of_taste_or_smell.checked=false;
				loss_of_taste_or_smell.disabled='disabled';

			}else{


				dry_cough.disabled=false;
				
				difficulty_in_breathing.disabled=false;
				
				fever.disabled=false;
			
				tiredness.disabled=false;
				
				loss_of_taste_or_smell.disabled=false;
			}
			}


	function none_of_the_above2_checked(){

	var none_of_the_above2 = document.getElementById("none_of_the_above2");
	var body_aches = document.getElementById("body_aches");
	var nasal_congestion = document.getElementById("nasal_congestion");
	var runny_nose = document.getElementById("runny_nose");
	var sore_throat = document.getElementById("sore_throat");
	var headache = document.getElementById("headache");

		if(none_of_the_above2.checked==true){

				body_aches.checked=false;
				body_aches.disabled='disabled';
				nasal_congestion.checked=false;
				nasal_congestion.disabled='disabled';
				runny_nose.checked=false;
				runny_nose.disabled='disabled';
				sore_throat.checked=false;
				sore_throat.disabled='disabled';
				headache.checked=false;
				headache.disabled='disabled';

			}else{


				body_aches.disabled=false;
				
				nasal_congestion.disabled=false;
				
				runny_nose.disabled=false;
			
				sore_throat.disabled=false;
				
				headache.disabled=false;
			}
			}


	function submit_basic_details(){

		if($("#full_name").val()!=''){

		$("#basic_details").css("display","none");
		$("#symptoms1").css("display","block");
		$("#symptoms1").addClass("animate__animated animate__fadeInRight");

		$("#progress_bar").css("width","40%");
		$("#progress_bar").css("transition","0.2s");

	}else{

		$("#error_msg").html("Please enter your name");
	}
	}


	function symptoms1(){

		var main_symptoms = [];
		$(".main_symptoms").each(function(){

			if ($(this).is(":checked")) {

				main_symptoms.push($(this).val());
			}
		});

		main_symptoms = main_symptoms.toString();

		if(main_symptoms!=''){

		$("#symptoms1").css("display","none");
		$("#symptoms2").css("display","block");
		$("#symptoms2").addClass("animate__animated animate__fadeInRight");

		$("#progress_bar").css("width","60%");
		$("#progress_bar").css("transition","0.2s");

	}else{

		$("#error_msg1").html("Please select atleast one");
	}
	}


	function symptoms2(){

		var other_symptoms = [];
		$(".other_symptoms").each(function(){

			if ($(this).is(":checked")) {

				other_symptoms.push($(this).val());
			}
		});

		other_symptoms = other_symptoms.toString();

		if (other_symptoms!='') {
		$("#symptoms2").css("display","none");
		$("#radio1").css("display","block");
		$("#radio1").addClass("animate__animated animate__fadeInRight");

		$("#progress_bar").css("width","80%");
		$("#progress_bar").css("transition","0.2s");

		}else{

			$("#error_msg2").html("Please select atleast one");
		}
	}


	//confirming
	function confirm(){


		var full_name = $("#full_name").val();
		var mobile_number = $("#mobile_number").val();



		var main_symptoms = [];
		$(".main_symptoms").each(function(){

			if ($(this).is(":checked")) {

				main_symptoms.push($(this).val());
			}
		});

		main_symptoms_array = main_symptoms;
		main_symptoms = main_symptoms.toString();

		//console.log(main_symptoms_array.length);




		var other_symptoms = [];
		$(".other_symptoms").each(function(){

			if ($(this).is(":checked")) {

				other_symptoms.push($(this).val());
			}
		});

		other_symptoms_array = other_symptoms;
		other_symptoms = other_symptoms.toString();




		var red_zone = [];

		$('input[name="red_zone"]').each(function(){

			if ($(this).is(":checked")) {

				red_zone.push($(this).val());
			}
		});

		red_zone = red_zone.toString();




		var healthcare = [];

		$('input[name="healthcare"]').each(function(){

			if ($(this).is(":checked")) {

				healthcare.push($(this).val());
			}
		});

		healthcare = healthcare.toString();



		var positive = [];

		$('input[name="positive"]').each(function(){

			if ($(this).is(":checked")) {

				positive.push($(this).val());
			}
		});

		positive = positive.toString();



		var condition = [];

		$('input[name="condition"]').each(function(){

			if ($(this).is(":checked")) {

				condition.push($(this).val());
			}
		});

		condition = condition.toString();


		function displayAdviceForLow(){

			$('#hi_name').html('Hi '+full_name+',');
			$('#hi_text').html('Don’t worry! As per our assessment, your risk of contracting the virus is low. However, given the rise of covid-19 cases in Bangladesh, you should follow the given guidelines below.');

			$("#check_btn").css("display","none");

			$("#our_advice").css("display","block");
			$("#our_advice_header").html("Our advice is as below:");
			$("#our_advice_text1").html("Stay at home");
			$("#our_advice_text2").html("Wash your hands frequently with soap and water for at least 30 seconds, cleaning your hands and arms");
			$("#our_advice_text3").html("Monitor the symptoms; if they increase or any of the other symptoms arise, then visit a medical practitioner who will advise you whether you need a test");
			$("#our_advice_text4").html("Eat nutrious, stay tension free and do mild exercises at home to stay active!");


			$("#our_advice_text11").css("display","block");
			$("#our_advice_text22").css("display","block");
			$("#our_advice_text33").css("display","block");
			$("#our_advice_text44").css("display","block");
			$("#our_advice_text55").css("display","none");
			$("#our_advice_text66").css("display","none");
			$("#our_advice_text77").css("display","none");


		}


		function displayAdviceForMedium(){

			$('#hi_name').html('Hi '+full_name+',');
			$('#hi_text').html('As per our assessment, please continue to self-quarantine at home, monitor your symptoms and follow the given guidelines below.');

			$("#check_btn").css("display","none");

			$("#our_advice").css("display","block");
			$("#our_advice_header").html("Our advice is as below:");
			$("#our_advice_text1").html("Stay at home");
			$("#our_advice_text2").html("Self-quarantine yourself");
			$("#our_advice_text3").html("Wear protective gear like a mask to protect close ones at home");
			$("#our_advice_text4").html("Wash your hands frequently with soap and water for at least 30 seconds, cleaning your hands and arms");
			$("#our_advice_text5").html("Dispose of any tissue used");
			$("#our_advice_text6").html("Monitor the symptoms; if they increase or any of the other symptoms arise, then visit a medical practitioner who will advise you whether you need a test");
			$("#our_advice_text7").html("Do not come in contact with people beyond your family members. If they go out for any essentials and come back, make sure they wash up before they touch anything at home.");

			$("#our_advice_text11").css("display","block");
			$("#our_advice_text22").css("display","block");
			$("#our_advice_text33").css("display","block");
			$("#our_advice_text44").css("display","block");
			$("#our_advice_text55").css("display","block");
			$("#our_advice_text66").css("display","block");
			$("#our_advice_text77").css("display","block");
		}


		function displayAdviceForHigh(){

			$('#hi_name').html('Hi '+full_name+',');
			$('#hi_text').html('As per our assessment, it is best to use the helpline number 91-11-23978046 or 1075 and speak to the respective medical practitioner on duty. Additionally, please follow the below guidelines to keep you and those around you, safe.');

			$("#check_btn").css("display","none");

			$("#our_advice").css("display","block");
			$("#our_advice_header").html("Our advice is as below:");
			$("#our_advice_text1").html("You may have to get a test for covid-19 done basis the advice of the medical practioner on duty");
			$("#our_advice_text2").html("You may find the list of test centres");
			$("#our_advice_text3").html("Stay at home");
			$("#our_advice_text4").html("Self-quarantine yourself");
			$("#our_advice_text5").html("Wear protective gear like a mask to protect close ones at home");
			$("#our_advice_text6").html("Wash your hands frequently with soap and water for at least 30 seconds, cleaning your hands and arms");
			$("#our_advice_text7").html("Dispose of any tissue used");


			$("#our_advice_text11").css("display","block");
			$("#our_advice_text22").css("display","block");
			$("#our_advice_text33").css("display","block");
			$("#our_advice_text44").css("display","block");
			$("#our_advice_text55").css("display","block");
			$("#our_advice_text66").css("display","block");
			$("#our_advice_text77").css("display","block");

		}


		function displayAdviceForUndetected(){

			$('#hi_name').html('Hi '+full_name+',');
			$('#hi_text').html('Sorry the result is undetectable for some conditions.');

			$("#check_btn").css("display","none");
		}

		/*red_zone = red_zone;*/

		//console.log(condition);

		//console.log(other_symptoms);

		/*var dry_cough = $("#dry_cough").val();
		var difficulty_in_breathing = $("#difficulty_in_breathing").val();
		var fever = $("#fever").val();
		var tiredness = $("#tiredness").val();
		var loss_of_taste_or_smell = $("#loss_of_taste_or_smell").val();
		var none_of_the_above1 = $("#none_of_the_above1").val();*/


		/*var body_aches = $("#body_aches").val();
		var sore_throat = $("#sore_throat").val();
		var nasal_congestion = $("#nasal_congestion").val();
		var headache = $("#headache").val();
		var runny_nose = $("#runny_nose").val();
		var none_of_the_above2 = $("#none_of_the_above2").val();*/


		/*var red_zone_yes = $("#red_zone_yes").val();
		var red_zone_no = $("#red_zone_no").val();
		var healthcare_yes = $("#healthcare_yes").val();
		var healthcare_no = $("#healthcare_no").val();
		var positive_yes = $("#positive_yes").val();
		var positive_no = $("#positive_no").val();
		var condition_yes = $("#condition_yes").val();
		var condition_no = $("#condition_no").val();*/
		console.log(positive);

		if (red_zone!='' && healthcare!='' && positive!='' && condition!='') {

			$("#user_name").html(full_name);
				$("#m_symptoms").html(main_symptoms);
				$("#o_symptoms").html(other_symptoms);

				$("#progress_bar").css("width","100%");
				$("#progress_bar").css("transition","0.2s");


				//all logics for symptoms checker
				if(main_symptoms_array.length==1 && other_symptoms=='None' && red_zone=='no' && healthcare=='no' && positive=='no' && condition=='no'){

				
				var risk = "Low";
				displayAdviceForLow();
				$(".count").html('Low Risk');
				$(".count").css('color','green');
				//document.getElementById("risk").style.color="green";
				//$("#risk").html("Low Risk");
				$(".circle_inner").css("border","6px solid green");
				

				}else if(main_symptoms=='None' && other_symptoms=='None' && red_zone=='no' && healthcare=='no' && positive=='no' && condition=='no'){

					var risk = "Low";
					displayAdviceForLow();
					$(".count").html('Low Risk');
					$(".count").css('color','green');
					//document.getElementById("risk").style.color="green";
					//$("#risk").html("Low Risk");
					$(".circle_inner").css("border","6px solid green");

				}else if(other_symptoms_array.length>=1 && main_symptoms=='None' && red_zone=='no' && healthcare=='no' && positive=='no' && condition=='no'){

					var risk = "Low";
					displayAdviceForLow();
					$(".count").html('Low Risk');
					$(".count").css('color','green');
					//document.getElementById("risk").style.color="green";
					//$("#risk").html("Low Risk");
					$(".circle_inner").css("border","6px solid green");

				}else if(other_symptoms=='None' && main_symptoms=='None' && red_zone=='no' && healthcare=='no' && positive=='no' && condition=='yes'){

					var risk = "Low";
					displayAdviceForLow();
					$(".count").html('Low Risk');
					$(".count").css('color','green');
					//document.getElementById("risk").style.color="green";
					//$("#risk").html("Low Risk");
					$(".circle_inner").css("border","6px solid green");

				}else if(main_symptoms_array.length>1 && other_symptoms=='None' && red_zone=='no' && healthcare=='no' && positive=='no' && condition=='no'){

					var risk = "Medium";
					displayAdviceForMedium();
					$(".count").html('Medium Risk');
					$(".count").css('color','orange');
					//document.getElementById("risk").style.color="orange";
					//$("#risk").html("Medium Risk");
					$(".circle_inner").css("border","6px solid orange");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && other_symptoms!='None' && other_symptoms_array.length>=1 && red_zone=='no' && healthcare=='no' && positive=='no' && condition=='no'){

					var risk = "Medium";
					displayAdviceForMedium();
					$(".count").html('Medium Risk');
					$(".count").css('color','orange');
					//document.getElementById("risk").style.color="orange";
					//$("#risk").html("Medium Risk");
					$(".circle_inner").css("border","6px solid orange");

				}else if(main_symptoms=='None' && other_symptoms=='None' && red_zone=='yes' && healthcare=='no' && positive=='no' && condition=='no'){

					var risk = "Medium";
					displayAdviceForMedium();
					$(".count").html('Medium Risk');
					$(".count").css('color','orange');
					//document.getElementById("risk").style.color="orange";
					//$("#risk").html("Medium Risk");
					$(".circle_inner").css("border","6px solid orange");

				}else if(main_symptoms=='None' && other_symptoms=='None' && red_zone=='no' && healthcare=='yes' && positive=='no' && condition=='no'){

					var risk = "Medium";
					displayAdviceForMedium();
					$(".count").html('Mediums Risk');
					$(".count").css('color','orange');
					//document.getElementById("risk").style.color="orange";
					//$("#risk").html("Medium Risk");
					$(".circle_inner").css("border","6px solid orange");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && other_symptoms=='None' && red_zone=='no' && healthcare=='yes' && positive=='no' && condition=='yes'){

					var risk = "Medium";
					displayAdviceForMedium();
					$(".count").html('Medium Risk');
					$(".count").css('color','orange');
					//document.getElementById("risk").style.color="orange";
					//$("#risk").html("Medium Risk");
					$(".circle_inner").css("border","6px solid orange");

				}else if(main_symptoms=='None' && other_symptoms_array.length>=1 && other_symptoms!='None' && red_zone=='no' && healthcare=='yes' && positive=='no' && condition=='yes'){

					var risk = "Medium";
					displayAdviceForMedium();
					$(".count").html('Medium Risk');
					$(".count").css('color','orange');
					//document.getElementById("risk").style.color="orange";
					//$("#risk").html("Medium Risk");
					$(".circle_inner").css("border","6px solid orange");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && other_symptoms_array.length>=1 && other_symptoms!='None' && red_zone=='yes' && (healthcare=='yes'||healthcare=='no') && (positive=='yes'||positive=='no') && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && other_symptoms_array.length>=1 && other_symptoms!='None' && (red_zone=='yes'||red_zone=='no') && (healthcare=='yes'||healthcare=='no') && positive=='yes' && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && other_symptoms_array.length>=1 && other_symptoms!='None' && (red_zone=='yes'||red_zone=='no') && (healthcare=='yes'||healthcare=='no') && (positive=='yes'||positive=='no') && condition=='yes'){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && other_symptoms_array.length>=1 && other_symptoms!='None' && red_zone=='yes' && (healthcare=='yes'||healthcare=='no') && (positive=='yes'||positive=='no') && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && (other_symptoms_array.length>=1 || other_symptoms=='None') && red_zone=='yes' && (healthcare=='yes'||healthcare=='no') && (positive=='yes'||positive=='no') && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && other_symptoms_array.length>=1 && other_symptoms!='None' && (red_zone=='yes'||red_zone=='no') && healthcare=='yes' && (positive=='yes'||positive=='no') && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && (other_symptoms_array.length>=1 || other_symptoms=='None') && (red_zone=='yes'||red_zone=='no') && healthcare=='yes' && (positive=='yes'||positive=='no') && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && other_symptoms_array.length>=1 && other_symptoms!='None' && (red_zone=='yes'||red_zone=='no') && (healthcare=='yes'||healthcare=='no') && positive=='yes' && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && (other_symptoms_array.length>=1 || other_symptoms=='None') && (red_zone=='yes'||red_zone=='no') && (healthcare=='yes'||healthcare=='no') && positive=='yes' && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if(main_symptoms_array.length>=1 && main_symptoms!='None' && other_symptoms_array.length>=1 && other_symptoms!='None' && (red_zone=='yes'||red_zone=='no') && (healthcare=='yes'||healthcare=='no') && positive=='yes' && condition=='yes'){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && (other_symptoms_array.length>=1 || other_symptoms=='None') && red_zone=='yes' && healthcare=='yes' && (positive=='yes'||positive=='no') && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && (other_symptoms_array.length>=1 || other_symptoms=='None') && red_zone=='yes' && (healthcare=='yes'||healthcare=='no') && positive=='yes' && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && (other_symptoms_array.length>=1 || other_symptoms=='None') && red_zone=='yes' && (healthcare=='yes'||healthcare=='no') && (positive=='yes'||positive=='no') && condition=='yes'){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && (other_symptoms_array.length>=1 || other_symptoms=='None') && (red_zone=='yes'||red_zone=='no') && healthcare=='yes' && positive=='yes' && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && (other_symptoms_array.length>=1 || other_symptoms=='None') && (red_zone=='yes'||red_zone=='no') && healthcare=='yes' && (positive=='yes'||positive=='no') && condition=='yes'){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && (other_symptoms_array.length>=1 || other_symptoms=='None') && (red_zone=='yes'||red_zone=='no') && (healthcare=='yes'||healthcare=='no') && positive=='yes' && condition=='yes'){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else if((main_symptoms_array.length>=1 || main_symptoms=='None') && (other_symptoms_array.length>=1 || other_symptoms=='None') && (red_zone=='yes'||red_zone=='no') && (healthcare=='yes'||healthcare=='no') && positive=='yes' && (condition=='yes'||condition=='no')){

					var risk = "High";
					displayAdviceForHigh();
					$(".count").html('High Risk');
					$(".count").css('color','red');
					$(".circle_inner").css("border","6px solid red");

				}else{

					var risk = "Undetected";
					displayAdviceForUndetected();
					$(".count").html('Udetectable');
					//$(".count").css('color','red');
					//$(".circle_inner").css("border","6px solid red");
				}



		$.ajax({

			url: 'confirm_symptom_checker.php',
			type: 'post',
			data : {

				full_name: full_name,
				mobile_number: mobile_number,
				main_symptoms: main_symptoms,
				other_symptoms: other_symptoms,
				red_zone: red_zone,
				healthcare: healthcare,
				positive: positive,
				condition: condition,
				risk: risk
			},

			beforeSend:function(){

			},

			success: function(data){

				

			}
		});

		window.location.replace("#result_area");

		//number increment animation
		/*$('.count').each(function () {
		    $(this).prop('Counter',0).animate({
		        Counter: $(this).text()
		    }, {
		        duration: 4000,
		        easing: 'swing',
		        step: function (now) {
		            $(this).text(Math.ceil(now));
		        }
		    });
		});*/


		$("#basic_details").css("display","block");
		$("#symptom1").css("display","none");
		$("#symptom2").css("display","none");
		$("#radio1").css("display","none");
		//$("#progress_bar").css("width","20%");
		$("#progress_bar").css("transition","0.2s");

		}else{

			$("#error_msg3").html("Please select atleast one from each question");
		}


	}

	
</script>

</body>

<!-- Mirrored from paul-themes.com/html/covid-19/symptom-checker.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 04 May 2021 12:12:30 GMT -->
</html>